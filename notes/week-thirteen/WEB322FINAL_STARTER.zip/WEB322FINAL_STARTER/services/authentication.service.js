class AuthenticationService {
  static authenticate(username, password) {
    return { isAutheticated: true, token: "sasaxsdlcihsdoichisdjnc" };
  }
}

module.exports = AuthenticationService;
